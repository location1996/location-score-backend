from fastapi import FastAPI
from fastapi.responses import FileResponse
from pydantic import BaseModel
from pathlib import Path
import uuid

from services.geocode import geocode
from services.isochrone import build_isochrone
from services.population import population_in_area
from services.competition import charging_competition
from services.scoring import score_location
from services.interpretation import interpret_score
from services.report import build_pdf

app = FastAPI(title="Charging Location Intelligence")

REPORTS_DIR = Path("reports")
REPORTS_DIR.mkdir(exist_ok=True)

class LocationRequest(BaseModel):
    address: str

@app.post("/analyze", response_class=FileResponse)
def analyze(req: LocationRequest):
    point = geocode(req.address)
    isochrone = build_isochrone(point, minutes=15)

    population = population_in_area(isochrone)
    competition = charging_competition(isochrone)

    score = score_location(population, competition)
    explanation = interpret_score(score, population, competition)

    report_id = str(uuid.uuid4())
    pdf_path = REPORTS_DIR / f"{report_id}.pdf"
    build_pdf(pdf_path, req.address, score, explanation, population, competition)

    return FileResponse(pdf_path)
