def interpret_score(score, population, competition):
    return f"""Der Standort erreicht ca. {population} Personen.
Es existieren {competition['stations']} Ladepunkte im Einzugsgebiet.
Charging-Score: {score}/100."""
