from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas

def build_pdf(path, address, score, text, population, competition):
    c = canvas.Canvas(str(path), pagesize=A4)
    c.drawString(50, 800, "Charging Location Intelligence Report")
    c.drawString(50, 770, f"Adresse: {address}")
    c.drawString(50, 740, f"Score: {score}/100")
    c.drawString(50, 710, f"Population: {population}")
    c.drawString(50, 690, f"Ladepunkte: {competition['stations']}")
    t = c.beginText(50, 650)
    for line in text.split("\n"):
        t.textLine(line)
    c.drawText(t)
    c.save()
