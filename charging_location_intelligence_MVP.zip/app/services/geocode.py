import requests

def geocode(address):
    r = requests.get(
        "https://nominatim.openstreetmap.org/search",
        params={"q": address, "format": "json", "limit": 1},
        headers={"User-Agent": "charging-intel"}
    ).json()
    return float(r[0]["lon"]), float(r[0]["lat"])
