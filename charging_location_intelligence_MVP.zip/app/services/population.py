# Auto-downloads DE population raster (Zensus) on first use
import os
import rasterio
from shapely.geometry import shape
from rasterio.mask import mask
import requests

DATA_PATH = "app/data/population.tif"

def download_population():
    if not os.path.exists(DATA_PATH):
        url = "https://github.com/johannesuhl/population_rasters/raw/master/germany_population_100m.tif"
        os.makedirs("app/data", exist_ok=True)
        r = requests.get(url)
        open(DATA_PATH, "wb").write(r.content)

def population_in_area(isochrone_geojson):
    download_population()
    geom = shape(isochrone_geojson["features"][0]["geometry"])
    with rasterio.open(DATA_PATH) as src:
        out_img, _ = mask(src, [geom], crop=True)
        return int(out_img.sum())
