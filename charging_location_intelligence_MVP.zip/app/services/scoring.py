def score_location(population, competition):
    pop_score = min(population / 50000, 1.0)
    comp_score = 0.8 if competition["stations"] < 5 else 0.5
    return round((0.6 * pop_score + 0.4 * comp_score) * 100)
