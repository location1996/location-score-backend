# Uses real OSM Overpass API
import requests

def charging_competition(isochrone_geojson):
    geom = isochrone_geojson["features"][0]["geometry"]
    query = f'''
    [out:json];
    node["amenity"="charging_station"](poly:"{geom['coordinates'][0]}");
    out;
    '''
    r = requests.post("https://overpass-api.de/api/interpreter", data=query).json()
    return {
        "stations": len(r.get("elements", [])),
        "density": "low" if len(r.get("elements", [])) < 5 else "medium"
    }
