import requests

def build_isochrone(point, minutes=15):
    lon, lat = point
    url = f"http://router.project-osrm.org/isochrone/v1/driving/{lon},{lat}"
    params = {"contours_minutes": minutes, "polygons": "true"}
    return requests.get(url, params=params).json()
